const nameGirl = 'Hồng Nhung';
const giftUrl = 'http://nodemy.vn';
const eventName = 'Happy Birthday';
const titleCard = 'Gửi Bé Vịt';
const contentCard = 'Chúc Vịt tuổi 18 thật nhiều thành công và ngày càng xinh đẹp, ráng kiếm được any chăm sóc cho nhá. Và tui chúc tuổi 18 cũng là sự khởi đầu của nhiều điều may mắn đến với Vịt đại gia ngầm';

// phần dưới dành cho các bạn biết code, nếu muốn chỉnh ảnh đơn giản với base64
// Cần hỗ trợ hãy liên hệ: 
// Mr-Nam http://facebook.com/nam.nodemy
// Các bạn muốn học lập trình thì tham gia Nhóm zalo tự học lập trình nhé: https://zalo.me/g/yhdkef092
const giftImage = 'hot-girl.png';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
